data:extend(
    {
       {
         type = "font",
         name = "seven",
         from = "seven",  -->  locale/_language_/info.json
         size = 14
      }
    })